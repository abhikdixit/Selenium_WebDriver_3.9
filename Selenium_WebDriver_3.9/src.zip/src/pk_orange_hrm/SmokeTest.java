package pk_orange_hrm;

import org.testng.annotations.Test;

public class SmokeTest {
  @Test
  public void SmokeTest_Execution() {
	  System.out.println("Smoke Test Execution Started");
  }
}
