package pk_orange_hrm;

import org.testng.annotations.Test;

public class SanityTest {
  @Test
  public void Sanity_Test() {
	  System.out.println("Sanity Test Started");
  }
}
