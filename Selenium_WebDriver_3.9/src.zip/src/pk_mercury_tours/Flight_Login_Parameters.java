package pk_mercury_tours;

import org.testng.annotations.Test;

public class Flight_Login_Parameters {
  @Test
  public void f() {
  }
}
