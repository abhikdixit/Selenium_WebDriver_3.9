package pk_mercury_tours;

import org.testng.annotations.Test;

public class BatchExecution_Smoke {
  @Test
  public void Batch_Smoke() {
	  System.out.println("Smoke Batch Started");
  }
}
