package pk_mercury_tours;

import org.testng.annotations.Test;

public class FlightLogin_Parameter {
  @Test
  public void f() {
	  
  }
}
