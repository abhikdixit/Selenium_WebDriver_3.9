package pk_mercury_tours;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Flight_Sign_In {
	ChromeDriver driver;
@Test
public void Sign_On()
	
	{
	driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
	driver.findElement(By.name("txtUsername")).sendKeys("Admin");
	driver.findElement(By.name("txtPassword")).sendKeys("admin123");
	driver.findElement(By.id("btnLogin")).click();
	String Element = driver.findElement(By.linkText("Dashboard")).getText();
	System.out.println(Element);
				
			}
@BeforeTest
public void LaunchBrowser()
	
	{
	String absolutePath=System.getProperty("user.dir");
	String filepath=absolutePath+"\\chromedriver.exe";
	
	System.setProperty("webdriver.chrome.driver",filepath);
	 	driver = new ChromeDriver();
	 	driver.manage().window().maximize();
	}
@AfterTest
public void CloseBrowser()
	
	{
		driver.quit();
	}
}
