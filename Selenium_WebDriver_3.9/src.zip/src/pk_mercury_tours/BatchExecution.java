package pk_mercury_tours;

import org.testng.annotations.Test;

public class BatchExecution {
  @Test
  public void TestSuite() {
	  System.out.println("Smoke Batch Execution Started");
  }
}
